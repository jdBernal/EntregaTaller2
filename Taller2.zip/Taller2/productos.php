<?php require_once('includes/database.php'); ?>
<!DOCTYPE html>
<html>
    <head>
        <title>Self Made Store</title>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">       
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
      

      <script src="js/jquery.js"></script>
      <script src="js/jquery.event.move.js"></script> 

        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
    <!-- Bootstrap -->
        

        <link href="css/bootstrap.min.css" rel="stylesheet">
           
        <link rel="stylesheet" href="css./styles.css">
       <link rel="stylesheet" href="css/main.css">  

        </head>


    <body id="fondo" >
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        <!-- Add your site or application content here -->
        <header id="elHeader" class="container">
          


        
           
              <div id="margenS">  
            
            <img id="logo" src="img/SMH_logo.png"  class="call-xs-4 call-sm-12" />
            <!-- <h1>This is web</h1> -->
            </div>
              <div class="row">
            <nav >
                
              
  

                    <ul id="BarraNav" class="nav nav-justified">
  
                <li class="active"><a href="index.php">Home</a></li>
                <li ><a href="Perfil.php">Profile</a></li>
                <li  ><a href="#">Products</a></li>           
                </ul>

                
            </nav>
            </div>
            






            </header>
       







<nav class="container" id="featured">
              <ul class="nav nav-justified">
  
                <li><a href="#">ALL NOVELS</a></li>
                         
                </ul>
</nav>



 
        





        <section id="seccion" class="container"> 
 
            <?php
                $query = "SELECT * FROM producto" ;
                $resultado = mysql_query($query) OR die("<p class='error'>Error de query: ".mysql_error()."</p></p>");

               
                      while ( $row = mysql_fetch_array($resultado) ) {
                    echo "<article id='cosas' class='col-sm-6 col-md-4' >";
                    echo "<div class='thumbnail' id='articulo'>";
                    echo "<img class='imagen' src='img/".$row["imagen"].".jpg' alt='...'>";
                    echo "<div class='caption'>";
                    echo "<h2>".$row["nombre"]."</h2>";
                    echo "<h5 class='autor'> Autor: ".$row["autor"]."</h5>";

                    echo "<p class='Sinopsis'>".$row["descripcion"]."</p>";
                    
                    echo "<div class='row'>";
                    echo "<div  align='right' class='span6  precio col-lg-4'><p class='precio'>$ ".$row["precio"]."</p></div>";
                    echo "<div align='left' 'class='span6  botonC col-lg-5'><a onclick='loadCompra()' class='btn btn-default btn-danger btn-md'><span class='glyphicon glyphicon-plus'></span> Add to Cart</a></p>";
                    echo " </div>";
                    echo " </div>";
                    echo " </div>"; 
                    echo " </div>";
                    echo "</article>";


                    
 
//     <div class="thumbnail">
//       <img data-src="holder.js/300x200" alt="...">
//       <div class="caption">
//         <h3>Thumbnail label</h3>
//         <p>...</p>
//         <p><a href="#" class="btn btn-primary" role="button">Button</a> <a href="#" class="btn btn-default" role="button">Button</a></p>
//       </div>
//     </div>
//   </div>
// </div>
                }
            ?>

        </section>



        <nav class="container" id="featured">
              <ul class="nav nav-justified">
  
                <li><p></p></li>
                         
                </ul>
</nav>


        

         <footer id="elFooter" class="container">
            <p class="row ">Julian Bernal 2014 </p>
        </footer>
         

    <!-- Include all compiled plugins (below), or include individual files as needed -->
   
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
     


    </body>
</html>
