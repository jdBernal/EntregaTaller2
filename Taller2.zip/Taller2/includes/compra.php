<?php
require_once('database.php');

$idProducto = $_POST["idProducto"];
$idCompra = $_POST["IdCompra"];

$query = " INSERT INTO relacion(`IdCompra`, `IdProducto`) VALUES (["$idProducto"],["$idCompra"])";

$resultado = mysql_query($query) OR die("Error de query: ".mysql_error());
echo "relacion ".$IdCompra." actualizado";
?>