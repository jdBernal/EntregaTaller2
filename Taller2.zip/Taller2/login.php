<?php 


include("includes/database.php");

$Username= $_POST['username'];
$Password= $_POST['password'];


$Username = stripslashes($Username);
$Password = stripslashes($Password);
$Username = mysql_real_escape_string($Username);
$Password = mysql_real_escape_string($Password);
$sql="SELECT * FROM usuario WHERE IdUsuario='$Username' and clave='$Password'";
$result=mysql_query($sql);
$count=mysql_num_rows($result);


if($count==1){



header("location:index.php?user=".$Username);
}
else {
echo "Wrong Username or Password";
}
?>