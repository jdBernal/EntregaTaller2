<?php require_once('includes/database.php'); ?>
<!DOCTYPE html>


<html>
    <head>
        <title>Self Made Store</title>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">       
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
      

      <script src="js/jquery.js"></script>
      <script src="js/jquery.event.move.js"></script> 

        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
    <!-- Bootstrap -->
        

        <link href="css/bootstrap.min.css" rel="stylesheet">
           
        <link rel="stylesheet" href="css./styles.css">
       <link rel="stylesheet" href="css/main.css">  







        </head>


    <body id="fondoLog" >
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

<div class="container">
    <div class="row">
        <div class="span12">
            <form class="form-horizontal" action="registroP.php" method="POST">
              <fieldset>
                <div id="legend">
                  <legend class="">Login</legend>
                </div>
                <div class="control-group">
                  <!-- Username -->
                  <label class="control-label"  for="username">Username</label>
                  <div class="controls">
                    <input type="text" id="username" name="username" placeholder="" class="input-xlarge">
                  </div>
                </div>
                <div class="control-group">
                  <!-- Password-->
                  <label class="control-label" for="password">Password</label>
                  <div class="controls">
                    <input type="password" id="password" name="password" placeholder="" class="input-xlarge">
                  </div>
                </div>
                <div class="control-group">
                  <!-- Button -->
                  <div class="controls">
                    <button class="btn btn-success botonR"  >Registrarse</button>
                  </div>
                </div>
              </fieldset>
            </form>
        </div>
    </div>
</div>


         

    <!-- Include all compiled plugins (below), or include individual files as needed -->
   
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
     


    </body>
</html>
