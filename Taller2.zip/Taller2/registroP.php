<?php
    include "includes/database.php";
   

$query = mysql_query("SELECT IdUsuario FROM usuario WHERE IdUsuario='username' ");
 if(mysql_num_rows($query)!=0)
   {
    echo"name already exists";
   }
 else
    {
       $sql="INSERT INTO usuario VALUES  ('".$_POST['username']."','".$_POST['password']."')";
            echo $sql;
             $result = mysql_query($sql);
                if (! $result){
                               echo "La consulta SQL contiene errores:".mysql_error();
                               exit();
                }else {
                  session_start();

                  $_SESSION['Usuario']=$_POST['username'];
                  $_SESSION['Password']='password';
                  header("location:index.php");
  }
    }
