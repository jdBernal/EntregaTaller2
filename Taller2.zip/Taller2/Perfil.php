<?php require_once('includes/database.php'); 


$user = 'Admin';


?>
<!DOCTYPE html>


<html>
    <head>
        <title>Self Made Store</title>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">       
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
      

      <script src="js/jquery.js"></script>
      <script src="js/jquery.event.move.js"></script> 

        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
    <!-- Bootstrap -->
        

        <link href="css/bootstrap.min.css" rel="stylesheet">
           
        <link rel="stylesheet" href="css./styles.css">
       <link rel="stylesheet" href="css/main.css">  




  
</script>

        </head>

    <body id="fondo" >

  
        <header id="elHeader" class="container">
          


       
           
            <div  class='row' id='margenS'>  
            
            <img id='logo' src='img/SMH_logo.png'  class='span6'/>   

              <?php
             echo "<div class=´row'>";
             echo "<p class='barWelcome'> Bienvenido! ".$user."<p>" ; 
             echo "<a class='barLogout' href='loginPage.php'> [Logout] </a>";
             echo "</div>";
            ?>
            

    </div>

            <!-- <h1>This is web</h1> -->
            </div>


              <div class="row">
            <nav >
                
             <ul id="BarraNav" class="nav nav-justified">
  

                 <li class="active"><a href="index.php">Home</a></li>
                 <li ><a href="Perfil.php">Profile</a></li>

                <li  ><a href="productos.php?user="a>Products</a></li>;
                 </ul>
            </nav>
            </div>
            </section>

            </header>
       







<nav class="container" id="featured">
              <ul class="nav nav-justified">
  
                <li><a href="#">FEATURED NOVELS</a></li>
                         
                </ul>
</nav>



 
        




        <section id="seccion" class="container"> 
 
            <?php
                $query = "SELECT * FROM compra WHERE IdUsuario ='Admin'";
                $resultado = mysql_query($query) OR die("<p class='error'>Error de query: ".mysql_error()."</p></p>");
                   while ( $row = mysql_fetch_array($resultado) ) {
                   
                   echo "<nav id='BarraCom'>";
                   echo "<article id='".$row["IdCompra"]."'>";
                   echo "<p class='fecha textLogin'> Fecha de Compra: ".$row["Fecha"]."'>";
                   echo "</nav>";

                    $query = "SELECT IdProducto FROM relacion WHERE idCompra=".$row["IdCompra"];
                    $resultado2 = mysql_query($query) OR die("<p class='error'>Error de query: ".mysql_error()."</p></p>");
                    while ( $row2 = mysql_fetch_array($resultado2)) {

                    $query = "SELECT * FROM producto WHERE idProducto=".$row2["IdProducto"];
                    $resultado3 = mysql_query($query) OR die("<p class='error'>Error de query: ".mysql_error()."</p></p>");
                    while ( $row3 = mysql_fetch_array($resultado3)) {

                 echo "<article id='cosas' class='col-sm-6 col-md-4' >";
                    echo "<div class='thumbnail' id='articulo'>";
                    echo "<img class='imagen' src='img/".$row3["imagen"].".jpg' alt='...'>";
                    echo "<div class='caption'>";
                    echo "<h2>".$row3["nombre"]."</h2>";
                    echo "<h5 class='autor'> Autor: ".$row3["autor"]."</h5>";

                    echo "<p class='Sinopsis'>".$row3["descripcion"]."</p>";
                    
                    echo "<div class='row'>";
                    echo "<div  align='right' class='span6  precio col-lg-4'><p class='precio'>$ ".$row3["precio"]."</p></div>";
                    echo "<div align='left' 'class='span6  botonC col-lg-5'><a onclick='loadCompra()' class='btn btn-default btn-danger btn-md'><span class='glyphicon glyphicon-plus'></span> Add to Cart</a></p>";
                    echo " </div>";
                    echo " </div>";
                    echo " </div>"; 
                    echo " </div>";
                    echo "</article>";
                    }
   
                }
            }
            ?>

        </section>

        <nav class="container" id="featured">
              <ul class="nav nav-justified">
  
                <li><p></p></li>
                         
                </ul>
</nav>



        

        <footer id="elFooter">
            <p>Powered by <a target="_blank" href="http://snowcone.com.co">Snowcone</a></p>
        </footer>
         

    <!-- Include all compiled plugins (below), or include individual files as needed -->
   
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
     


    </body>
</html>
